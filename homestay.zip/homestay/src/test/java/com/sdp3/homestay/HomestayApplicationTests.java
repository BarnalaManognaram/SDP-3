package com.sdp3.homestay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomestayApplicationTests {

	@Test
	void contextLoads() {
	}

}
